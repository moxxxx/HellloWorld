Author: Jiujiu Duan Student ID: 101094923
Purpose: A C program to simulate a race between a tortoise and a hare.
Files:  assignment1.c README.txt

To compile the code:  type the following code in console. (Make sure that you are in the right directory where assignment1.c is)
'gcc -o assignment1 assignment1.c'
To launch the code: type the following code in the console.(Make sure that you are in the right directory where assignment1 is)
'./assignment1'
